# Serverless DynamoDB excercise
This project is for serverless DynamoDB excercise.
It
1. Recieves google clientId and client information and stores it in dynamoDB.
2. Expose functionalaity to update information based on google clientId back to Google Analytics.
